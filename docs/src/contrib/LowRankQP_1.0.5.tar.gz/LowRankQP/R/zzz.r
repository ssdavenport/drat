.onAttach <- function(libname,pkgname)
{
   packageStartupMessage("LowRankQP 1.0 loaded\nCopyright J.T. Ormerod & M. P. Wand 2020")
}
